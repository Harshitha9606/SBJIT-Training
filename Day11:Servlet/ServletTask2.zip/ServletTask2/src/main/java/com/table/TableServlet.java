package com.table;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/TableServlet")
public class TableServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        String name = request.getParameter("Name");
        String email = request.getParameter("Email");
        String course = request.getParameter("Course");

        HttpSession session = request.getSession();

        List<Student> students =
                (List<Student>) session.getAttribute("students");

        if (students == null) {
            students = new ArrayList<>();
        }

        if (name != null && email != null && course != null) {
            Student student = new Student(name, email, course);
            students.add(student);
        }

        session.setAttribute("students", students);

        out.println("<html><body>");
        out.println("<h2>Student Details</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Name</th><th>Email</th><th>Course</th></tr>");

        for (Student s : students) {
            out.println("<tr>");
            out.println("<td>" + s.getName() + "</td>");
            out.println("<td>" + s.getEmail() + "</td>");
            out.println("<td>" + s.getCourse() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("<br><a href='index.html'>Add Another Student</a>");
        out.println("</body></html>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}
