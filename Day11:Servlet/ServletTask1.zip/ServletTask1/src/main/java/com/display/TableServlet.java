package com.display;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TableServlet
 */
@WebServlet("/TableServlet")
public class TableServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public TableServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter printwriter=response.getWriter();
		String name=request.getParameter("Name");
		String email=request.getParameter("Email");
		String course=request.getParameter("Course");
		
		  printwriter.println("<html><body>");
		  printwriter.println("<table border='1'>");

		  printwriter.println("<tr><th>Name</th><td>" + name + "</td></tr>");
		  printwriter.println("<tr><th>Email</th><td>" + email + "</td></tr>");
		  printwriter.println("<tr><th>Course</th><td>" + course + "</td></tr>");

		  printwriter.println("</table>");
		  printwriter.println("</body></html>");	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
